# Operating-System
Lab Practicals of Operating System
